import "../client/global.css";
import { createRoot } from "react-dom/client";
import AdminApp from "./AdminApp";

createRoot(document.getElementById("root")!).render(<AdminApp />);
